package com.springProj.springproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringprojApplicationTests {

	@Test
	void contextLoads() {
	}

}
